from flask import Flask,render_template,request
import pickle
import numpy as np
app=Flask(__name__)
model=pickle.load(open('model.pkl','rb'))
@app.route('/')
def home():
    return render_template('home.html')
@app.route('/predict',methods=['POST'])
def predict():
   value = [float(x) for x in request.form.values()]
   if value[5]==2.0 or value[6]==2.0:
       anyl=1.0
   else:
       anyl=0.0
   value=[value[0],value[1],value[2],value[3],value[4],value[6],value[7],value[8],
          value[9],value[11],value[14],value[16],value[17],value[19],anyl]
   value=[np.array(value)]
   prediction=model.predict(value)
   output=prediction[0]
   return render_template ('result.html',prediction_text="The willingness of this Customer to subscribe a term deposit is : {} !!!".format(output))
if __name__=='__main__':
    app.run(port=8000)