# Term deposit prediction model
import pandas as pd
import numpy as np
import pickle
#reading dataset
df = pd.read_csv("bank-additional-full.csv", sep=';')
#missing value handling data
df=df[(df['default']!='unknown')&(df['job']!='unknown')&(df['marital']!='unknown')
      &(df['education']!='unknown')&(df['loan']!='unknown')
      &(df['housing']!='unknown')|(df['y']=='yes')]
# removing unwanted features
df1=df.drop(['duration','pdays','previous'],axis=1)
#outlier handling
for i in ["age", "campaign"]:
        for j in df1["y"].unique():
            target_type = df1[df1["y"] == j]
            column = target_type[i]
            q1 = column.quantile(0.25) 
            q3 = column.quantile(0.75) 
            iqr = q3 - q1 
            upper_limit = q3 + 1.5 * iqr
            lower_limit = q1 - 1.5 * iqr        
            outliers = column[(column > upper_limit) | (column < lower_limit)].index 
            df1.drop(index= outliers, inplace=True)
#feature engineering
df1["any_loan"]=(df1["housing"]=='yes')| (df1["loan"]=='yes')
#label encoding
from sklearn.preprocessing import LabelEncoder
label_en=LabelEncoder()
for i in df1.columns:
    if df1[i].dtype ==  bool or df1[i].dtype == object and i!='y':
        df1[i]=label_en.fit_transform(df1[i])
# Splitting Target and featrues
y = df1['y']
X = df1.drop('y', axis = 1)
#featre reduction
corr=X.corr()
columns = np.full((corr.shape[0]), True, dtype=bool)
for i in range(corr.shape[0]):
    for j in range(i+1, corr.shape[0]):
        if corr.iloc[i,j] >= 0.8 or corr.iloc[i,j] <= -0.8:
            if columns[i]:
                columns[i] = False
selected_columns = X.columns[columns]
X = X[selected_columns]
#oversampling
from imblearn.over_sampling import SMOTE
X_smote, y_smote = SMOTE(sampling_strategy='auto', random_state = 0, k_neighbors=5).fit_resample(X,y)
#spliting train and test
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test=train_test_split(X_smote, y_smote,random_state=5,test_size=.3)
# random forest Classifier
from sklearn.ensemble import RandomForestClassifier
rand_f=RandomForestClassifier(n_estimators=120, max_depth=200, random_state=123, criterion="entropy")
#Fitting the model
m=rand_f.fit(X_train,y_train)
#Saving the model to disk
pickle.dump(rand_f,open('model.pkl','wb') )